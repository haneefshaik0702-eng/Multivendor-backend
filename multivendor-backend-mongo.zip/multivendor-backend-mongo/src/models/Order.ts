import { Schema, model } from 'mongoose';

const OrderSchema = new Schema({
  customerId: String,
  items: [{ productId: String, qty: Number }],
  totalCents: Number,
  address: Object
}, { timestamps: true });

export default model('Order', OrderSchema);
